import React, { useState, useEffect } from 'react';
import { Calendar as CalendarIcon, ChevronLeft, ChevronRight } from 'lucide-react';

interface ChooseDateStepProps {
  onDateSelected: (date: string) => void;
  value?: string;
}

const ChooseDateStep: React.FC<ChooseDateStepProps> = ({ onDateSelected, value }) => {
  const [dates, setDates] = useState<Date[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Generate next 14 days
    const nextDates: Date[] = [];
    const today = new Date();
    for (let i = 0; i < 14; i++) {
      const d = new Date(today);
      d.setDate(today.getDate() + i);
      nextDates.push(d);
    }
    setDates(nextDates);
    setLoading(false);
  }, []);

  const formatDateValue = (date: Date) => date.toISOString().split('T')[0];

  const isSelected = (date: Date) => value === formatDateValue(date);

  const getDayName = (date: Date) => {
    return date.toLocaleDateString('pt-BR', { weekday: 'short' }).replace('.', '');
  };

  const getDayNumber = (date: Date) => {
    return date.getDate();
  };

  const getMonthName = (date: Date) => {
    return date.toLocaleDateString('pt-BR', { month: 'long' });
  };

  if (loading) {
    return (
      <div className="w-full max-w-4xl mx-auto p-4 animate-pulse">
        <div className="h-8 w-48 bg-gray-200 rounded mb-6"></div>
        <div className="flex space-x-4 overflow-hidden">
          {[1, 2, 3, 4, 5].map(i => (
             <div key={i} className="w-24 h-28 bg-gray-100 rounded-xl flex-shrink-0"></div>
          ))}
        </div>
      </div>
    );
  }

  // Group by currently selected month (visual aid)
  const currentMonth = dates.length > 0 ? getMonthName(dates[0]) : '';

  return (
    <div className="w-full max-w-4xl mx-auto px-4 py-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Escolha a Data</h2>
          <p className="text-slate-500 capitalize">{currentMonth}</p>
        </div>
        <div className="p-2 bg-indigo-50 text-indigo-600 rounded-full">
          <CalendarIcon className="w-6 h-6" />
        </div>
      </div>

      <div className="relative group">
        {/* Helper gradient for scroll indication if needed, utilizing standard scrollbar styling via Tailwind */}
        <div className="flex overflow-x-auto pb-6 space-x-4 snap-x scrollbar-hide -mx-4 px-4 sm:mx-0 sm:px-0">
          {dates.map((date) => {
            const selected = isSelected(date);
            const isToday = new Date().toDateString() === date.toDateString();
            
            return (
              <button
                key={date.toISOString()}
                onClick={() => onDateSelected(formatDateValue(date))}
                className={`
                  snap-start flex-shrink-0 flex flex-col items-center justify-center w-20 h-28 rounded-2xl border transition-all duration-200
                  ${selected 
                    ? 'bg-indigo-600 border-indigo-600 text-white shadow-lg shadow-indigo-200 scale-105' 
                    : 'bg-white border-gray-200 text-slate-600 hover:border-indigo-300 hover:bg-gray-50'
                  }
                `}
              >
                <span className={`text-xs font-medium uppercase tracking-wide mb-1 ${selected ? 'text-indigo-200' : 'text-slate-400'}`}>
                  {getDayName(date)}
                </span>
                <span className={`text-2xl font-bold ${selected ? 'text-white' : 'text-slate-800'}`}>
                  {getDayNumber(date)}
                </span>
                {isToday && (
                  <span className={`mt-2 text-[10px] font-bold px-2 py-0.5 rounded-full ${selected ? 'bg-indigo-500 text-white' : 'bg-green-100 text-green-700'}`}>
                    Hoje
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>
      
      {!value && (
         <div className="text-center mt-4 text-sm text-slate-400 animate-pulse">
           Selecione um dia para ver os horários
         </div>
      )}
    </div>
  );
};

export default ChooseDateStep;