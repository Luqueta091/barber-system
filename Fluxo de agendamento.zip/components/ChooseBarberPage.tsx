import React, { useState, useEffect } from 'react';
import { User } from 'lucide-react';
import { Barber, MOCK_BARBERS } from '../types';

interface ChooseBarberPageProps {
  onSelect?: (barber: Barber) => void;
  selectedId?: string;
}

const ChooseBarberPage: React.FC<ChooseBarberPageProps> = ({ onSelect, selectedId }) => {
  const [barbers, setBarbers] = useState<Barber[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Simulating API Call logic - preserving functionality structure
  useEffect(() => {
    const fetchBarbers = async () => {
      try {
        setLoading(true);
        // Simulate network delay
        await new Promise(resolve => setTimeout(resolve, 800)); 
        setBarbers(MOCK_BARBERS);
        setLoading(false);
      } catch (err) {
        setError("Erro ao carregar barbeiros.");
        setLoading(false);
      }
    };
    fetchBarbers();
  }, []);

  if (loading) {
    return (
      <div className="w-full max-w-3xl mx-auto p-4 animate-pulse">
        <div className="h-8 w-48 bg-gray-200 rounded mb-6"></div>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="bg-gray-100 h-32 rounded-xl"></div>
          ))}
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="w-full max-w-3xl mx-auto p-8 text-center bg-red-50 rounded-xl border border-red-100">
        <p className="text-red-600 font-medium">{error}</p>
        <button 
          onClick={() => window.location.reload()}
          className="mt-4 px-4 py-2 text-sm text-red-700 bg-red-100 rounded-lg hover:bg-red-200 transition-colors"
        >
          Tentar novamente
        </button>
      </div>
    );
  }

  if (barbers.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center p-12 text-gray-500 bg-white rounded-xl shadow-sm border border-gray-100">
        <User className="w-12 h-12 mb-4 text-gray-300" />
        <p>Nenhum barbeiro disponível no momento.</p>
      </div>
    );
  }

  return (
    <div className="w-full max-w-4xl mx-auto px-4 py-6">
      <h2 className="text-2xl font-bold text-slate-900 mb-2">Escolha seu Profissional</h2>
      <p className="text-slate-500 mb-8">Selecione o especialista de sua preferência.</p>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-5">
        {barbers.map((barber) => {
          const isSelected = selectedId === barber.id;
          return (
            <div
              key={barber.id}
              onClick={() => onSelect && onSelect(barber)}
              className={`
                group relative flex flex-col items-center justify-center p-6 rounded-2xl cursor-pointer transition-all duration-200 border
                ${isSelected 
                  ? 'border-indigo-600 bg-indigo-50 ring-2 ring-indigo-600 ring-offset-2' 
                  : 'border-gray-200 bg-white hover:border-indigo-300 hover:shadow-lg'
                }
              `}
            >
              <h3 className="text-lg font-bold text-slate-900 text-center mb-4">{barber.name}</h3>
              
              <div className={`w-full py-2 rounded-lg text-sm font-medium text-center transition-colors
                ${isSelected 
                  ? 'bg-indigo-600 text-white shadow-indigo-200' 
                  : 'bg-gray-100 text-slate-600 group-hover:bg-indigo-100 group-hover:text-indigo-700'
                }
              `}>
                {isSelected ? 'Selecionado' : 'Selecionar'}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default ChooseBarberPage;