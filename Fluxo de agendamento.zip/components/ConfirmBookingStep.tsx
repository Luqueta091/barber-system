import React, { useState } from 'react';
import { Calendar, Clock, User, Scissors, CheckCircle, Loader2 } from 'lucide-react';

interface Slot {
  inicio: string;
  fim: string;
}

interface ConfirmBookingStepProps {
  barbeiroId: string;
  servicoId: string;
  slot: Slot;
  onSuccess?: () => void;
}

const ConfirmBookingStep: React.FC<ConfirmBookingStepProps> = ({ 
  barbeiroId, 
  servicoId, 
  slot, 
  onSuccess 
}) => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));
    setSubmitting(false);
    if (onSuccess) onSuccess();
  };

  return (
    <div className="w-full max-w-2xl mx-auto px-4 py-6">
      <h2 className="text-2xl font-bold text-slate-900 mb-6 text-center">Confirmar Agendamento</h2>

      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden mb-8">
        <div className="bg-indigo-600 px-6 py-4">
          <h3 className="text-white font-medium flex items-center gap-2">
            <CheckCircle className="w-5 h-5 text-indigo-200" />
            Resumo do Pedido
          </h3>
        </div>
        
        <div className="p-6 space-y-4">
          <div className="flex items-start gap-4 p-3 bg-gray-50 rounded-xl">
             <div className="bg-white p-2 rounded-lg border border-gray-200 text-indigo-600">
               <Scissors className="w-5 h-5" />
             </div>
             <div>
               <p className="text-xs text-gray-500 uppercase tracking-wide font-semibold">Serviço</p>
               <p className="text-slate-900 font-medium">Serviço ID: {servicoId}</p>
             </div>
          </div>

          <div className="flex items-start gap-4 p-3 bg-gray-50 rounded-xl">
             <div className="bg-white p-2 rounded-lg border border-gray-200 text-indigo-600">
               <User className="w-5 h-5" />
             </div>
             <div>
               <p className="text-xs text-gray-500 uppercase tracking-wide font-semibold">Profissional</p>
               <p className="text-slate-900 font-medium">Barbeiro ID: {barbeiroId}</p>
             </div>
          </div>

          <div className="flex gap-4">
            <div className="flex-1 flex items-start gap-3 p-3 bg-gray-50 rounded-xl">
               <div className="bg-white p-2 rounded-lg border border-gray-200 text-indigo-600">
                 <Clock className="w-5 h-5" />
               </div>
               <div>
                 <p className="text-xs text-gray-500 uppercase tracking-wide font-semibold">Horário</p>
                 <p className="text-slate-900 font-bold">{slot.inicio}</p>
               </div>
            </div>
             <div className="flex-1 flex items-start gap-3 p-3 bg-gray-50 rounded-xl">
               <div className="bg-white p-2 rounded-lg border border-gray-200 text-indigo-600">
                 <Calendar className="w-5 h-5" />
               </div>
               <div>
                 <p className="text-xs text-gray-500 uppercase tracking-wide font-semibold">Duração</p>
                 <p className="text-slate-900 font-medium">30 min</p>
               </div>
            </div>
          </div>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-5">
        <div>
          <label htmlFor="name" className="block text-sm font-medium text-slate-700 mb-1">Nome Completo</label>
          <input
            id="name"
            type="text"
            required
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 outline-none transition-all"
            placeholder="Ex: João Silva"
          />
        </div>

        <div>
          <label htmlFor="phone" className="block text-sm font-medium text-slate-700 mb-1">Telefone / WhatsApp</label>
          <input
            id="phone"
            type="tel"
            required
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 outline-none transition-all"
            placeholder="(11) 99999-9999"
          />
        </div>

        <button
          type="submit"
          disabled={submitting}
          className={`
            w-full flex items-center justify-center py-4 rounded-xl font-bold text-lg text-white shadow-lg transition-all
            ${submitting 
              ? 'bg-indigo-400 cursor-not-allowed' 
              : 'bg-indigo-600 hover:bg-indigo-700 hover:shadow-indigo-200 hover:-translate-y-0.5'
            }
          `}
        >
          {submitting ? (
            <>
              <Loader2 className="w-5 h-5 animate-spin mr-2" />
              Confirmando...
            </>
          ) : (
            'Confirmar Agendamento'
          )}
        </button>
      </form>
    </div>
  );
};

export default ConfirmBookingStep;