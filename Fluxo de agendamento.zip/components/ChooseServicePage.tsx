import React, { useState, useEffect } from 'react';
import { Check, Clock, ChevronRight } from 'lucide-react';
import { Service, MOCK_SERVICES } from '../types';

interface ChooseServicePageProps {
  onSelect?: (service: Service) => void;
  selectedId?: string;
}

const ChooseServicePage: React.FC<ChooseServicePageProps> = ({ onSelect, selectedId }) => {
  const [services, setServices] = useState<Service[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchServices = async () => {
      try {
        setLoading(true);
        await new Promise(resolve => setTimeout(resolve, 600));
        setServices(MOCK_SERVICES);
        setLoading(false);
      } catch (err) {
        setError("Não foi possível carregar os serviços.");
        setLoading(false);
      }
    };
    fetchServices();
  }, []);

  if (loading) {
    return (
      <div className="w-full max-w-2xl mx-auto p-4 space-y-4">
        <div className="h-8 w-1/3 bg-gray-200 rounded mb-8"></div>
        {[1, 2, 3].map(i => (
          <div key={i} className="h-24 bg-gray-100 rounded-xl animate-pulse"></div>
        ))}
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-6 text-center text-red-600 bg-red-50 rounded-xl border border-red-100 mx-auto max-w-xl">
        {error}
      </div>
    );
  }

  return (
    <div className="w-full max-w-3xl mx-auto px-4 py-6">
      <h2 className="text-2xl font-bold text-slate-900 mb-2">Selecione o Serviço</h2>
      <p className="text-slate-500 mb-8">O que vamos fazer hoje?</p>

      <div className="space-y-4">
        {services.map((service) => {
          const isSelected = selectedId === service.id;
          return (
            <div
              key={service.id}
              onClick={() => onSelect && onSelect(service)}
              className={`
                group relative flex items-center p-5 rounded-xl cursor-pointer border transition-all duration-200
                ${isSelected 
                  ? 'border-indigo-600 bg-indigo-50/50 shadow-md ring-1 ring-indigo-600' 
                  : 'border-gray-200 bg-white hover:border-indigo-300 hover:shadow-md'
                }
              `}
            >
              <div className={`
                flex-shrink-0 w-6 h-6 rounded-full border-2 mr-4 flex items-center justify-center transition-colors
                ${isSelected ? 'border-indigo-600 bg-indigo-600 text-white' : 'border-gray-300 text-transparent group-hover:border-indigo-400'}
              `}>
                <Check className="w-3.5 h-3.5" strokeWidth={3} />
              </div>

              <div className="flex-grow min-w-0">
                <div className="flex items-center justify-between mb-1">
                  <h3 className={`font-semibold text-lg ${isSelected ? 'text-indigo-900' : 'text-slate-900'}`}>
                    {service.name}
                  </h3>
                  <span className={`font-bold text-lg ${isSelected ? 'text-indigo-700' : 'text-slate-900'}`}>
                    R$ {service.price.toFixed(2)}
                  </span>
                </div>
                
                <div className="flex items-center text-sm text-slate-500 gap-4">
                  <div className="flex items-center gap-1.5 bg-gray-100 px-2 py-0.5 rounded-md">
                    <Clock className="w-3.5 h-3.5" />
                    <span>{service.durationMinutes} min</span>
                  </div>
                  {service.description && (
                     <span className="truncate hidden sm:inline-block border-l border-gray-300 pl-4">
                       {service.description}
                     </span>
                  )}
                </div>
                {service.description && (
                  <p className="text-sm text-slate-500 mt-2 sm:hidden line-clamp-2">
                    {service.description}
                  </p>
                )}
              </div>
              
              <div className={`ml-4 text-slate-300 ${isSelected ? 'text-indigo-400' : 'group-hover:text-indigo-400'}`}>
                 <ChevronRight className="w-5 h-5" />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default ChooseServicePage;