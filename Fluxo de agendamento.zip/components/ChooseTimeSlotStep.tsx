import React, { useState, useEffect } from 'react';
import { Clock, Sun, Moon, Coffee } from 'lucide-react';
import { TimeSlot } from '../types';

interface ChooseTimeSlotStepProps {
  barbeiroId: string;
  servicoId: string;
  date: Date;
  onSlotSelected: (slot: TimeSlot) => void;
  selectedSlot?: TimeSlot | null;
}

const ChooseTimeSlotStep: React.FC<ChooseTimeSlotStepProps> = ({ 
  barbeiroId, 
  servicoId, 
  date, 
  onSlotSelected, 
  selectedSlot 
}) => {
  const [slots, setSlots] = useState<TimeSlot[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchSlots = async () => {
      setLoading(true);
      setSlots([]); // clear previous
      setError(null);
      
      try {
        // Mock fetch delay
        await new Promise(resolve => setTimeout(resolve, 500));
        
        // Mock logic to generate slots
        const mockSlots: TimeSlot[] = [];
        const startHour = 9;
        const endHour = 19;
        
        for (let h = startHour; h < endHour; h++) {
          mockSlots.push({ inicio: `${h}:00`, fim: `${h}:30`, available: Math.random() > 0.3 });
          mockSlots.push({ inicio: `${h}:30`, fim: `${h+1}:00`, available: Math.random() > 0.3 });
        }
        setSlots(mockSlots);
      } catch (err) {
        setError("Erro ao buscar horários.");
      } finally {
        setLoading(false);
      }
    };

    if (date && barbeiroId && servicoId) {
      fetchSlots();
    }
  }, [date, barbeiroId, servicoId]);

  if (loading) {
    return (
      <div className="w-full max-w-3xl mx-auto p-4">
         <div className="h-6 w-32 bg-gray-200 rounded mb-4"></div>
         <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-3">
            {[...Array(12)].map((_, i) => (
              <div key={i} className="h-10 bg-gray-100 rounded-lg animate-pulse"></div>
            ))}
         </div>
      </div>
    );
  }

  if (error) {
    return <div className="p-4 text-center text-red-500 bg-red-50 rounded-lg">{error}</div>;
  }

  const morningSlots = slots.filter(s => parseInt(s.inicio) < 12);
  const afternoonSlots = slots.filter(s => parseInt(s.inicio) >= 12 && parseInt(s.inicio) < 18);
  const eveningSlots = slots.filter(s => parseInt(s.inicio) >= 18);

  const renderSection = (title: string, icon: React.ReactNode, sectionSlots: TimeSlot[]) => {
    if (sectionSlots.length === 0) return null;
    return (
      <div className="mb-6">
        <div className="flex items-center gap-2 mb-3 text-slate-500">
          {icon}
          <h3 className="text-sm font-semibold uppercase tracking-wider">{title}</h3>
        </div>
        <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 gap-3">
          {sectionSlots.map((slot, index) => {
             const isSelected = selectedSlot?.inicio === slot.inicio;
             const isAvailable = slot.available;

             return (
               <button
                key={`${slot.inicio}-${index}`}
                disabled={!isAvailable}
                onClick={() => onSlotSelected(slot)}
                className={`
                  relative py-2 px-1 rounded-lg text-sm font-medium border transition-all duration-150
                  ${!isAvailable 
                    ? 'bg-gray-50 text-gray-300 border-gray-100 cursor-not-allowed decoration-slice' 
                    : isSelected
                      ? 'bg-indigo-600 text-white border-indigo-600 shadow-md transform scale-105'
                      : 'bg-white text-slate-700 border-gray-200 hover:border-indigo-400 hover:text-indigo-600 hover:bg-indigo-50'
                  }
                `}
               >
                 {slot.inicio}
                 {!isAvailable && (
                   <span className="absolute inset-0 flex items-center justify-center">
                     <span className="w-full h-px bg-gray-300 transform -rotate-12"></span>
                   </span>
                 )}
               </button>
             );
          })}
        </div>
      </div>
    );
  };

  return (
    <div className="w-full max-w-4xl mx-auto px-4 py-6">
      <h2 className="text-2xl font-bold text-slate-900 mb-6">Selecione o Horário</h2>
      
      {slots.length === 0 ? (
        <div className="text-center py-10 bg-gray-50 rounded-xl border border-dashed border-gray-300 text-gray-400">
           Nenhum horário disponível para esta data.
        </div>
      ) : (
        <div className="bg-white rounded-xl p-2 sm:p-0">
          {renderSection('Manhã', <Coffee className="w-4 h-4" />, morningSlots)}
          {renderSection('Tarde', <Sun className="w-4 h-4" />, afternoonSlots)}
          {renderSection('Noite', <Moon className="w-4 h-4" />, eveningSlots)}
        </div>
      )}
    </div>
  );
};

export default ChooseTimeSlotStep;