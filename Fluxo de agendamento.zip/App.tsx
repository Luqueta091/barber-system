import React, { useState } from 'react';
import ChooseBarberPage from './components/ChooseBarberPage';
import ChooseServicePage from './components/ChooseServicePage';
import ChooseDateStep from './components/ChooseDateStep';
import ChooseTimeSlotStep from './components/ChooseTimeSlotStep';
import ConfirmBookingStep from './components/ConfirmBookingStep';
import { Barber, Service, TimeSlot } from './types';
import { ArrowLeft, CheckCircle2 } from 'lucide-react';

const App = () => {
  const [step, setStep] = useState(1);
  const [selectedBarber, setSelectedBarber] = useState<Barber | null>(null);
  const [selectedService, setSelectedService] = useState<Service | null>(null);
  const [selectedDate, setSelectedDate] = useState<string>('');
  const [selectedSlot, setSelectedSlot] = useState<TimeSlot | null>(null);
  const [isBooked, setIsBooked] = useState(false);

  const handleBack = () => {
    if (step > 1) setStep(step - 1);
  };

  const resetFlow = () => {
    setStep(1);
    setSelectedBarber(null);
    setSelectedService(null);
    setSelectedDate('');
    setSelectedSlot(null);
    setIsBooked(false);
  };

  if (isBooked) {
    return (
      <div className="min-h-screen bg-white flex flex-col items-center justify-center p-6 text-center">
        <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mb-6">
          <CheckCircle2 className="w-10 h-10 text-green-600" />
        </div>
        <h1 className="text-3xl font-bold text-slate-900 mb-2">Agendamento Confirmado!</h1>
        <p className="text-slate-500 mb-8 max-w-md">Seu horário foi reservado com sucesso. Enviamos os detalhes para o seu WhatsApp.</p>
        <button 
          onClick={resetFlow}
          className="px-8 py-3 bg-slate-900 text-white rounded-xl font-medium hover:bg-slate-800 transition-colors"
        >
          Novo Agendamento
        </button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-10 px-4 h-16 flex items-center justify-between">
        <div className="flex items-center gap-4">
          {step > 1 && (
            <button 
              onClick={handleBack}
              className="p-2 rounded-full hover:bg-gray-100 text-slate-600 transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
          )}
          <h1 className="font-bold text-lg text-slate-900">
            {step === 1 && "Profissional"}
            {step === 2 && "Serviço"}
            {step === 3 && "Data e Hora"}
            {step === 4 && "Confirmação"}
          </h1>
        </div>
        <div className="text-sm font-medium text-indigo-600 bg-indigo-50 px-3 py-1 rounded-full">
          Passo {step}/4
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-grow flex flex-col">
        {step === 1 && (
          <ChooseBarberPage 
            onSelect={(barber) => {
              setSelectedBarber(barber);
              setStep(2);
            }} 
            selectedId={selectedBarber?.id} 
          />
        )}

        {step === 2 && (
          <ChooseServicePage 
            onSelect={(service) => {
              setSelectedService(service);
              setStep(3);
            }} 
            selectedId={selectedService?.id} 
          />
        )}

        {step === 3 && (
          <div className="w-full max-w-4xl mx-auto space-y-2">
            <ChooseDateStep 
              onDateSelected={(date) => setSelectedDate(date)} 
              value={selectedDate} 
            />
            
            {selectedDate && selectedBarber && selectedService && (
              <ChooseTimeSlotStep
                barbeiroId={selectedBarber.id}
                servicoId={selectedService.id}
                date={new Date(selectedDate)}
                onSlotSelected={(slot) => setSelectedSlot(slot)}
                selectedSlot={selectedSlot}
              />
            )}

            {selectedSlot && (
              <div className="fixed bottom-0 left-0 right-0 p-4 bg-white border-t border-gray-200 flex justify-center shadow-lg sm:static sm:bg-transparent sm:border-0 sm:shadow-none sm:p-0 sm:mt-8">
                <button
                  onClick={() => setStep(4)}
                  className="w-full sm:w-auto px-8 py-3 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 transition-colors"
                >
                  Continuar
                </button>
              </div>
            )}
            
            {/* Spacer for mobile fixed button */}
            <div className="h-20 sm:hidden"></div>
          </div>
        )}

        {step === 4 && selectedBarber && selectedService && selectedSlot && (
          <ConfirmBookingStep 
            barbeiroId={selectedBarber.id}
            servicoId={selectedService.id}
            slot={selectedSlot}
            onSuccess={() => setIsBooked(true)}
          />
        )}
      </main>
    </div>
  );
};

export default App;