export interface Barber {
  id: string;
  name: string;
  avatarUrl: string;
  specialty?: string;
  rating?: number;
}

export interface Service {
  id: string;
  name: string;
  price: number;
  durationMinutes: number;
  description?: string;
}

export interface TimeSlot {
  inicio: string; // "HH:mm"
  fim: string;    // "HH:mm"
  available: boolean;
}

// Mock Data helpers (Simulating API responses for the UI components)
export const MOCK_BARBERS: Barber[] = [
  { id: '1', name: 'Carlos Silva', avatarUrl: 'https://picsum.photos/200?random=1', specialty: 'Degradê & Barba', rating: 4.8 },
  { id: '2', name: 'André Souza', avatarUrl: 'https://picsum.photos/200?random=2', specialty: 'Corte Clássico', rating: 4.9 },
  { id: '3', name: 'Marcos Oliveira', avatarUrl: 'https://picsum.photos/200?random=3', specialty: 'Coloração', rating: 4.7 },
];

export const MOCK_SERVICES: Service[] = [
  { id: '1', name: 'Corte de Cabelo', price: 45, durationMinutes: 30, description: 'Corte completo com lavagem e finalização.' },
  { id: '2', name: 'Barba Completa', price: 35, durationMinutes: 20, description: 'Barba com toalha quente e navalha.' },
  { id: '3', name: 'Combo Corte + Barba', price: 70, durationMinutes: 50, description: 'O serviço completo para renovar o visual.' },
];